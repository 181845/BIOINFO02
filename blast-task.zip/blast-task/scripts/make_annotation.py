"""Build results/annotation_table.csv: top 10 hits + a few hits chosen for interpretation."""
import csv
hits = list(csv.DictReader(open("results/all_hits.csv")))
rank = {h["accession"]: i + 1 for i, h in enumerate(hits)}
by = {h["accession"]: h for h in hits}

notes = {
 "P69905.2": "Query itself (HBA1/HBA2 protein). 142/142 identical, no gaps. Expected self-hit, confirms the search worked.",
 "P01923.1": "Gorilla ortholog. 1 substitution in 141 aligned residues; 99% cover only because the gorilla sequence is 1 aa shorter (0 gaps).",
 "Q9TS35.2": "Gibbon alpha-1 ortholog. 140/142 identical; very recent divergence from human.",
 "P06635.2": "Orangutan ortholog. 139/142 identical.",
 "P01924.1": "Langur (Old World monkey) ortholog. 138/141 identical.",
 "P63107.2": "Japanese macaque ortholog. 138/142 identical.",
 "P67817.2": "Spider monkey (New World monkey) ortholog. Identity drops to ~96% as divergence time increases.",
 "Q9TS34.2": "Gibbon alpha-2 ortholog (second alpha gene copy in gibbon). Slightly lower identity than alpha-1.",
 "P18972.1": "Silvery marmoset ortholog. 137/141 identical.",
 "P01926.2": "Grivet monkey ortholog. 137/142 identical.",
 "P01935.1": "Chimp alpha-3. Only ~89% identical although the chimp main alpha chain is 100% identical to human (see P69907). Lower identity suggests a diverged duplicate (paralog), not the true ortholog. Inference from identity pattern.",
 "P01942.2": "Mouse ortholog. ~86% identical across the full length; typical human-rodent conservation for a core protein.",
 "P01966.2": "Cow ortholog. 88% identical; shows conservation across mammalian orders.",
 "P01948.2": "Rabbit ortholog. Lowest identity in the 100-hit list (82%), still E-value ~1e-85, so clearly homologous.",
}
extra = [  # hits merged with the human hit in the alignment file (identical sequences)
 dict(rank="1 (tie)", accession="P69906.2", protein="Hemoglobin subunit alpha", organism="Pan paniscus",
      pct_identity="100.00", query_cover_pct="100", evalue="2e-100", bit_score="286",
      interpretation="Bonobo alpha chain. Identical to human over 142 aa. Listed with the human hit in the alignment file."),
 dict(rank="1 (tie)", accession="P69907.2", protein="Hemoglobin subunit alpha", organism="Pan troglodytes",
      pct_identity="100.00", query_cover_pct="100", evalue="2e-100", bit_score="286",
      interpretation="Chimpanzee alpha chain. Identical to human over 142 aa. Listed with the human hit in the alignment file."),
]

chosen = [h["accession"] for h in hits[:10]] + ["P01935.1", "P01942.2", "P01966.2", "P01948.2"]
rows = []
for a in chosen:
    h = by[a]
    rows.append(dict(rank=rank[a], accession=a, protein=h["protein"], organism=h["organism"],
                     pct_identity=h["pct_identity"], query_cover_pct=h["query_cover_pct"],
                     evalue=h["evalue"], bit_score=h["bit_score"], interpretation=notes[a]))
rows[1:1] = extra  # put the two tied identical hits right after the human self-hit
cols = ["rank","accession","protein","organism","pct_identity","query_cover_pct","evalue","bit_score","interpretation"]
with open("results/annotation_table.csv","w",newline="",encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n"); w.writeheader(); w.writerows(rows)
print(len(rows), "rows written")
