"""Parse the NCBI BLAST text download into CSV tables and a query FASTA.

Usage: python scripts/make_tables.py
Input : results/blast_alignment_EH27Z1N3014.txt  (NCBI "Alignment" text download)
Output: results/all_hits.csv, results/annotation_table.csv, query.fasta
"""
import csv, re

SRC = "results/blast_alignment_EH27Z1N3014.txt"
lines = open(SRC, encoding="utf-8").read().splitlines()

# ---- 1. summary table (one row per hit) --------------------------------
row_re = re.compile(
    r"\s(\d+)\s+(\d+)\s+(\d+)%\s+(\S+)\s+([\d.]+)\s+(\d+)\s+([A-Z0-9]+\.\d+)\s*$")
hits = []
for ln in lines:
    m = row_re.search(ln)
    if m and ln.startswith(("RecName", "SubName")):
        score, total, cover, ev, ident, alen, acc = m.groups()
        hits.append(dict(accession=acc, bit_score=score,
                         query_cover_pct=cover, evalue=ev,
                         pct_identity=ident, subject_length=alen))

# ---- 2. alignment section: full names, organisms, identities ----------
info, group = {}, []
i = lines.index("Alignments:")
while i < len(lines):
    ln = lines[i]
    if ln.startswith(">"):
        name = ln[1:]
        org = re.search(r"\[([^\]]+)\]\s*$", name)
        acc = lines[i + 1].split()[2]
        group.append((acc, name, org.group(1) if org else ""))
        i += 2
        continue
    if ln.startswith("Identities:") and group:
        ident = re.search(r"Identities:(\d+)/(\d+)", ln)
        pos = re.search(r"Positives:(\d+)/(\d+)", ln)
        gaps = re.search(r"Gaps:(\d+)/(\d+)", ln)
        for acc, name, org in group:
            info.setdefault(acc, dict(
                protein=re.search(r"Full=([^;\[]+)", name).group(1).strip(),
                organism=org,
                identities=f"{ident.group(1)}/{ident.group(2)}",
                positives=f"{pos.group(1)}/{pos.group(2)}",
                gaps=f"{gaps.group(1)}/{gaps.group(2)}"))
        group = []
    i += 1

for h in hits:
    h.update(info.get(h["accession"], {}))

cols = ["accession", "protein", "organism", "pct_identity", "query_cover_pct",
        "evalue", "bit_score", "identities", "positives", "gaps", "subject_length"]
with open("results/all_hits.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
    w.writeheader(); w.writerows(hits)

# ---- 3. query FASTA from the 100% identity self-hit --------------------
q = []
for ln in lines:
    m = re.match(r"Query\s+\d+\s+([A-Z]+)\s+\d+$", ln)
    if m: q.append(m.group(1))
    if ln.startswith("Score:") and q and len(q) >= 3: break
seq = "".join(q[:3])
with open("query.fasta", "w") as f:
    f.write(">NP_000508.1 hemoglobin subunit alpha [Homo sapiens]\n")
    for k in range(0, len(seq), 60): f.write(seq[k:k+60] + "\n")
print(len(hits), "hits parsed; query length", len(seq))
